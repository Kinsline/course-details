package com.example.Course.Registration.System.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Course.Registration.System.modal.Course;
import com.example.Course.Registration.System.modal.CourseRegistry;
import com.example.Course.Registration.System.repository.CourseRegistryRepo;
import com.example.Course.Registration.System.repository.CourseRepo;

@Service
public class CourseService {
	
	
	@Autowired
	CourseRepo courseRepo;

	public List<Course> availableCourse() {
		// TODO Auto-generated method stub
		return courseRepo.findAll();
	}
	
	@Autowired
	CourseRegistryRepo courseRegistryRepo;

	public List<CourseRegistry> enrolledStudents() {
		// TODO Auto-generated method stub
		return courseRegistryRepo.findAll();
	}
	
	public void enrollCourse(String name,String emailId,String courseName) 
	{
		CourseRegistry courseRegistry=new CourseRegistry(name,emailId,courseName);
		courseRegistryRepo.save(courseRegistry);
	}

}
