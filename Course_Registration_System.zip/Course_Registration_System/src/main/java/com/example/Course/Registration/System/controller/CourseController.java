package com.example.Course.Registration.System.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.Course.Registration.System.modal.Course;
import com.example.Course.Registration.System.modal.CourseRegistry;
import com.example.Course.Registration.System.service.CourseService;

@RestController
public class CourseController {
	
	@Autowired
	CourseService courseService;
	@CrossOrigin (origins = "http://localhost:5500")
	@GetMapping("/course")
	public List<Course>availableCourse(){
		return courseService.availableCourse();
	}

		@GetMapping("/course/enrolled")
		public List<CourseRegistry>enrolledStudents(){
			return courseService.enrolledStudents();
		}
		
	
			@PostMapping("/course/register")
			public String enrollCourse(@RequestParam("name")String name,
										@RequestParam("emailId")String emailId,
										@RequestParam("courseName")String courseName)
		
			{
				
				courseService.enrollCourse(name,emailId,courseName);
				return"congragulations!" +name+ "Enrollment Successful for" +courseName;
			}
				
			
	}

