
function showCourses() {
    fetch("http://localhost:8080/course")
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then((course) => {
            const dataTable = document.getElementById("coursetable");
            course.forEach(course => {
                const row = `
                    <tr>
                        <td>${course.courseId}</td>
                        <td>${course.courseName}</td>
                        <td>${course.trainer}</td>
                        <td>${course.durationInWeeks}</td>
                    </tr>
                `;
                dataTable.innerHTML += row;
            });
        })
        .catch((error) => {
            console.error("Error fetching courses:", error);
            alert("Failed to load course data. Please try again later.");
        });
}

function showEnrolledStudents() {
   fetch("http://localhost:8080/course/enrolled")
        .then((response) => response.json())
        .then((students) => {
            const dataTable = document.getElementById("enrolledtable");
            students.forEach(course => {
                var row = `<tr>
                        <td>${students.name}</td>
                        <td>${students.emailId}</td>
                        <td>${students.courseName}</td>
                    </tr>
                `;
                dataTable.innerHTML += row;
            });
        });
}